package com.po21x.uas_180010151;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.po21x.uas_180010151.databinding.FragmentFirstBinding;

import java.util.ArrayList;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private RecyclerView recyclerView;
    private RecycleViewAdapter adapter;
    private ArrayList<ScoreRecord> scoreArrayList;
    SQLiteDatabase db;
    Cursor cursor;
    database dbScore;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbScore = new database(getActivity());
        db = dbScore.getWritableDatabase();
        dbScore.createTable(db);
        cursor = db.rawQuery("select * from Score", null);

        if(!cursor.moveToNext()){
            dbScore.generatedata(db);
        }
        addData();
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        adapter = new RecycleViewAdapter(scoreArrayList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);


        /*binding.buttonFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });*/
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void addData(){
        cursor = db.rawQuery("select * from Score", null);
        scoreArrayList = new ArrayList<>();
        if(cursor.moveToFirst()){
            do {
                scoreArrayList.add(new ScoreRecord(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6)));
            } while (cursor.moveToNext());
        }

    }

}