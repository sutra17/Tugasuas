package com.po21x.uas_180010151;

public class ScoreRecord {
    private String namaTeam1;
    private String namaTeam2;
    private String score1;
    private String score2;
    private String img1;
    private String img2;
    private String id;

    public ScoreRecord(String id, String namaTeam1, String namaTeam2, String score1, String score2, String img1, String img2)
    {
        this.namaTeam1=namaTeam1;
        this.namaTeam2=namaTeam2;
        this.score1=score1;
        this.score2=score2;
        this.img1 = img1;
        this.img2 = img2;
        this.id=id;
    }

    public String getNamaTeam1(){
        return namaTeam1;
    }
    public String getId(){
        return id;
    }
    public String getNamaTeam2(){
        return namaTeam2;
    }
    public String getImg1(){
        return img1;
    }
    public String getImg2(){
        return img2;
    }
    public String getScore1(){
        return score1;
    }
    public String getScore2(){
        return score2;
    }


    public void setNamaTeam1(String namaTeam){
        this.namaTeam1=namaTeam;
    }
    public void setNamaTeam2(String namaTeam){
        this.namaTeam2=namaTeam;
    }
    public void setId(String id){
        this.id=id;
    }
    public void setScore1(String score){
        this.score1=score;
    }
    public void setScore2(String score){
        this.score2=score;
    }
    public void setImg1(String img){
        this.img1=img;
    }
    public void setImg2(String img){
        this.img2=img;
    }
}
