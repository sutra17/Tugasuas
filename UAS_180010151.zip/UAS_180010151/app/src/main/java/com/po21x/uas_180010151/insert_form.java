package com.po21x.uas_180010151;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;


public class insert_form extends AppCompatActivity {
    SQLiteDatabase db;
    Cursor cursor;
    database dbScore;
    Button save;
    EditText editScore1, editScore2, editNama1,editNama2, editUrl1, editUrl2;
    TextView label1, label2;
    private ArrayList<ScoreRecord> scoreArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_form);
        editScore1 = (EditText) findViewById(R.id.editTextScore1);
        editScore2 = (EditText) findViewById(R.id.editTextScore2);
        editNama1 = (EditText) findViewById(R.id.editTextNama1);
        editNama2 = (EditText) findViewById(R.id.editTextNama2);
        editUrl1 = (EditText) findViewById(R.id.editTextUrl1);
        editUrl2 = (EditText) findViewById(R.id.editTextUrl2);
        label1 = (TextView) findViewById(R.id.TextView_labelScore);
        label2 = (TextView) findViewById(R.id.textView_labelScore2);
        dbScore = new database(this);
        db =dbScore.getWritableDatabase();
        dbScore.createTable(db);
        save = (Button) findViewById(R.id.button3);
        save.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        db.execSQL("insert into Score (namateam1, namateam2, score1, score2, img1, img2) values('" +
                                editNama1.getText()+"', '"+
                                editNama2.getText()+"', '"+
                                editScore1.getText()+"', '"+
                                editScore2.getText()+"', '"+
                                editUrl1.getText()+"', '"+
                                editUrl2.getText()+
                                "')");
                        gototab1();
                    }
                }
        );

    }
    private void addData(int id){
        cursor = db.rawQuery("select * from Score where _id =" +id, null);
        scoreArrayList = new ArrayList<>();
        if(cursor.moveToFirst()){
            do {
                scoreArrayList.add(new ScoreRecord(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6)));
                label1.setText(cursor.getString(1));
                label2.setText(cursor.getString(2));
                editNama1.setText(cursor.getString(1));
                editNama2.setText(cursor.getString(2));
                editScore1.setText(cursor.getString(3));
                editScore2.setText(cursor.getString(4));
                editUrl1.setText(cursor.getString(5));
                editUrl2.setText(cursor.getString(6));
            } while (cursor.moveToNext());
        }
    }
    private void gototab1(){
        Intent i = new Intent (this,MainActivity.class);
        startActivity(i);
    }
}