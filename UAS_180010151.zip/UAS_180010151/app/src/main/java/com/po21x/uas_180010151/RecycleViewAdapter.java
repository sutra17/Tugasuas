package com.po21x.uas_180010151;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.CardViewHolder> {

    private ArrayList<ScoreRecord> localDataSet;

    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public class CardViewHolder extends RecyclerView.ViewHolder {
        private TextView txtScore1, txtScore2, txtName1, txtName2;
        private  ImageView imgFlag1, imgFlag2;
        private ImageButton editButton;
        public CardViewHolder(View view) {
            super(view);
            // Define click listener for the ViewHolder's View
            imgFlag1 = (ImageView) view.findViewById(R.id.imageView2);
            imgFlag2 = (ImageView) view.findViewById(R.id.imageView3);
            txtScore1 = (TextView) view.findViewById(R.id.score1);
            txtScore2 = (TextView) view.findViewById(R.id.score2);
            txtName1 = (TextView) view.findViewById(R.id.team1_name_text);
            txtName2 = (TextView) view.findViewById(R.id.team2_name_text);
            editButton = (ImageButton) view.findViewById(R.id.imageButton);
        }
    }

    /**
     * Initialize the dataset of the Adapter.
     *
     * @param dataSet String[] containing the data to populate views to be used
     * by RecyclerView.
     */
    public RecycleViewAdapter(ArrayList<ScoreRecord> dataSet) {
        this.localDataSet = dataSet;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public CardViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.card_item, viewGroup, false);

        return new CardViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(CardViewHolder viewHolder, int position) {

        // Get element from your dataset at this position and replace the
        // contents of the view with that element
        Glide.with(viewHolder.itemView.getContext())
                .load(localDataSet.get(position).getImg1())
                .apply(new RequestOptions().override(256,374))
                .into(viewHolder.imgFlag1);
        Glide.with(viewHolder.itemView.getContext())
                .load(localDataSet.get(position).getImg2())
                .apply(new RequestOptions().override(256,374))
                .into(viewHolder.imgFlag2);
        viewHolder.txtScore1.setText(localDataSet.get(position).getScore1());
        viewHolder.txtScore2.setText(localDataSet.get(position).getScore2());
        viewHolder.txtName1.setText(localDataSet.get(position).getNamaTeam1());
        viewHolder.txtName2.setText(localDataSet.get(position).getNamaTeam2());
        viewHolder.editButton.setOnClickListener(view -> {
            String id =localDataSet.get(position).getId();
            Intent i = new Intent(view.getContext(), updateForm.class);
            i.putExtra("id",id);
            view.getContext().startActivity(i);

        });

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return (localDataSet != null) ? localDataSet.size() : 0;
    }
}
