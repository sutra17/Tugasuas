package com.po21x.uas_180010151;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class database extends SQLiteOpenHelper {
    public database(@Nullable Context context) {
        super(context, "UAS", null, 1);
    }

    public void createTable(SQLiteDatabase db){
        db.execSQL("create table if not exists Score "+
                "(_id integer primary key autoincrement not null,"+
                "namateam1 text, namateam2 text, score1 int, score2 int, img1 text, img2 text)");
    }

    public void generatedata(SQLiteDatabase db)
    {
        ContentValues cv = new ContentValues();
        cv.put("namateam1", "Barcelona");
        cv.put("namateam2", "Real Madrid");
        cv.put("score1", 2);
        cv.put("score2", 2);
        cv.put("img1", "https://upload.wikimedia.org/wikipedia/id/thumb/4/47/FC_Barcelona_%28crest%29.svg/1200px-FC_Barcelona_%28crest%29.svg.png");
        cv.put("img2", "https://upload.wikimedia.org/wikipedia/id/8/8b/Real_Madrid_Club_de_F%C3%BAtbol.png");
        db.insert("Score", "namateam1", cv);
    }

    public List<String> getAllLabels() {
        List<String> labels = new ArrayList<String>();

        // Select All Query
        String selectQuery = "SELECT * FROM Tugas";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                labels.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }
        // closing connection


        // returning lables
        return labels;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
